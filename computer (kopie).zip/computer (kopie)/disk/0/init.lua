function get_network_event()
    local timer = os.startTimer(0)
    local events = { os.pullEvent() }
    local modem_message = false
    local modem_events = {}
    for _, event in pairs(events) do
        if type(event) == "table" and modem_message then
            modem_events[#modem_events+1] = event
        end
        if event == "modem_message" then
            modem_message = true
        end
        if event == "redstone" then
            modem_events[#modem_events+1] = {event=0, event="redstone"}
        end
    end
    return modem_events
end

function TableConcat(t1,t2)
    for i=1,#t2 do
        t1[#t1+1] = t2[i]
    end
    return t1
end

local child_ports = {}

function combine(x, y)
    local w = {}
    for k, i in pairs(x) do
        if k ~= nil then
            w[k] = {i, nil}
        end
    end
    for k, i in pairs(y) do
        if w[k] ~= nil then
            w[k][2] = i
        else
            w[k] = {nil, i}
        end
    end
    return w
end
