local modem = peripheral.find("modem") or error("No internet connection")
local port = os.getComputerID()
local parentPort = 0
local size = 0
local refresh_side = "left"

modem.transmit(hub_port, hub_port, "turnOn")

modem.open(parentPort)
modem.open(port)

local function get_inventory()
    local inventory = {}
    local size = 0
    local chests = {peripheral.find("minecraft:chest", function(name, chest)
        local size = size + chest.size()
        for slot, item in pairs(chest.list()) do
            local metaData = chest.getItemMeta(slot)
            if item ~= nil then
                item.nbtHash = item.nbtHash or item.name 
                if inventory[item.nbtHash] == nil then 
                    inventory[item.nbtHash] = metaData
                 else
                    inventory[item.nbtHash].count = metaData.count + inventory[item.nbtHash].count   
                end
            end
        end        
    end)}
    return inventory
end

local prev_inv = {}
local prev_serial_inv = ""
local function get_changes() 
    local changes = {}
    local changed = false
    local inv = get_inventory()
    local serial_inv = textutils.serialize(inv)
    
    if prev_serial_inv ~= serial_inv then
        print("change")
        for nbtHash, items in pairs(combine(prev_inv, inv)) do
            if items[1] == nil then
                changes[nbtHash] = items[2]
            else if items[2] == nil then
                changes[nbtHash] = items[1].count * -1
            else if items[1].count ~= items[2].count then
                print(item[1])
                changes[nbtHash] = items[2].count - items[1].count
            end end end
        end
        prev_serial_inv = serial_inv
        prev_inv = inv
        print(textutils.serialize(changes))
        return changes
    end
    
    return nil    
end

repeat
    local refresh_request = get_network_event()[1]
    if refresh_request ~= nil then
        modem.transmit(0,0, {event = 2, inventory = get_inventory(), sender = port})
    end
    
    local changes = get_changes()
    if changes ~= nil then
        modem.transmit(0,0, {event=1, changes = changes, sender = port})
    end
until false
