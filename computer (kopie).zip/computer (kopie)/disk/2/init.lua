local monitor = peripheral.find("modem")
local modem = peripheral.find("modem") or error("No internet connection")
local port = 0
local refresh_side = "left"
local wait_time = 200
local ignored_events = {}
local hub_port = 128

modem.transmit(hub_port, hub_port, "turnOn")

modem.open(port)

local function update_screen(inventory)
    print("update_screen mate")
    monitor.clear()
    monitor.setTextColor(1)
    monitor.setCursorPos(1, 1)
    monitor.write("Inventory:")
    monitor.setCursorPos(1, 2)
    for nbtHash, item in pairs(inventory) do
        monitor.write(item.displayName .. ": " .. item.count)    
        local x, y = monitor.getCursorPos()
        monitor.setCursorPos(1, y+1)
    end    
end

update_screen({})

local child_ports = {}

local event_functions = { 
    [0] = function(_, _)
        print("Refresh!")

        modem.transmit(0, 0, {})
        local time = 0
        local inventory = {}
        
        repeat
            local modem_events = get_network_event()
            if #modem_events > 0 then
                print("start special man")
                for _, message in pairs(modem_events) do
                    print(table.unpack(message), message.event, "message modem special man!!")
                    if message.event == 2 then
                         child_ports[#child_ports+1] = message.sender
                         for nbtHash, item in pairs(message.inventory) do
                             if nbtHash ~= nil and item ~= nil then 
                                 if inventory[nbtHash] == nil then
                                     inventory[nbtHash] = item
                                 else
                                     inventory[nbtHash].count = item.count + inventory[nbtHash].count
                                 end
                             end
                         end
                    else
                        ignored_events[#ignored_events+1] = message
                    end
                end
            end
            if time > wait_time then
               break
            end
            time = time + 1
        until false
        print(textutils.serialize(inventory))
        return inventory
    end,
    [1] = function(changes, inventory)
        print("Changement!")
        changes = changes.changes
        for name, item in pairs(changes) do
--            print(type(item))
            if type(item) == "number" then
                print(textutils.serialize(inventory[nam]))
                inventory[name].count = item + inventory[name].count
            else
               if inventory[name] == nil then
                   inventory[name] = item
               else
                   inventory[name].count = item.count + inventory[name].count
               end
            end
        end
        return inventory
    end,
    [128] = function(error, inventory)
        return inventory
    end
}

local inventory = {}

repeat
    local network_events = get_network_event()
    local refresh = false
    for _, message in pairs(TableConcat(network_events, ignored_events)) do
        if message ~= nil or (redstone.getInput(refresh_side) and message.event == "redstone") then
            print("message!")
            if message.event ~= 0 then
                local event_function = event_functions[message.event or 128] or function() end
                inventory = event_function(message, inventory)
                update_screen(inventory)
            else
                refresh = true
            end
        end
    end
    if refresh then
        inventory = event_functions[0](nil, nil)
        update_screen(inventory)
    end
    ignored_events = {}
until false
