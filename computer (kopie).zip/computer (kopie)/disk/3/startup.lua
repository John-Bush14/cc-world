local port = 128

peripheral.find("modem").open(port)

function getDisks()
    local disks = {}
    local drives = {peripheral.find("drive", function(name, drive)
        if drive.isDiskPresent() then
            disks[drive.getDiskLabel()] = drive.getMountPath()
        end
    end)}
    return disks
end

function switchDisk(disk)
    if fs.exists(disk .. "/startup.lua") then
        fs.move(disk .. "/startup.lua", disk .. "/init.lua")
        return
    end
    fs.move(disk .. "/init.lua", disk .. "/startup.lua")
end

local disks = getDisks()
require("../" .. disks.tools .. "/init")
switchDisk(disks.hub)
print("switch!")

local computers = {peripheral.find("computer", function(name, computer)
    print(name, computer.getLabel())
    if computer.getLabel() == "hub" then return end
    
    print("cmp!")
    if computer.getLabel() == "manager" then
        switchDisk(disks.manager)
    else
        switchDisk(disks.inventory)
    end
    
    computer.reboot()
    os.pullEvent("modem_message")
        
    if computer.getLabel() ~= "manager" then
        switchDisk(disks.manager)
        return
    end     
    switchDisk(disks.inventory)
end)}

print("endswitch!")
switchDisk(disks.hub)
